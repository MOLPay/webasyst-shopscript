<?php
/**
 * Describe payment plugin requirements
 * TODO link to plugin's system requirements
 */
return array(
    'php.curl'      => array(
        'strict' => true,
        'value'  => 1,
    ),
    'app.installer' => array(
        'version' => '1.2.1.31586',
        'strict'  => true
    ),
);
